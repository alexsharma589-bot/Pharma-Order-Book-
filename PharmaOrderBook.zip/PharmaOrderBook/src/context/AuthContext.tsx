import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';
import * as Crypto from 'expo-crypto';

const PIN_KEY = 'pharma_app_pin_hash';

interface AuthContextValue {
  isUnlocked: boolean;
  hasPinSet: boolean;
  loading: boolean;
  setPin: (pin: string) => Promise<void>;
  unlockWithPin: (pin: string) => Promise<boolean>;
  unlockWithBiometrics: () => Promise<boolean>;
  lock: () => void;
  biometricsAvailable: boolean;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function hashPin(pin: string): Promise<string> {
  return Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, pin);
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [hasPinSet, setHasPinSet] = useState(false);
  const [loading, setLoading] = useState(true);
  const [biometricsAvailable, setBiometricsAvailable] = useState(false);

  useEffect(() => {
    (async () => {
      const storedHash = await SecureStore.getItemAsync(PIN_KEY);
      setHasPinSet(Boolean(storedHash));
      const compatible = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      setBiometricsAvailable(compatible && enrolled);
      setLoading(false);
    })();
  }, []);

  const setPin = useCallback(async (pin: string) => {
    const hash = await hashPin(pin);
    await SecureStore.setItemAsync(PIN_KEY, hash);
    setHasPinSet(true);
    setIsUnlocked(true);
  }, []);

  const unlockWithPin = useCallback(async (pin: string) => {
    const storedHash = await SecureStore.getItemAsync(PIN_KEY);
    if (!storedHash) return false;
    const candidateHash = await hashPin(pin);
    const ok = candidateHash === storedHash;
    if (ok) setIsUnlocked(true);
    return ok;
  }, []);

  const unlockWithBiometrics = useCallback(async () => {
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: 'Unlock Pharma Order Book',
      fallbackLabel: 'Use PIN',
    });
    if (result.success) setIsUnlocked(true);
    return result.success;
  }, []);

  const lock = useCallback(() => setIsUnlocked(false), []);

  return (
    <AuthContext.Provider
      value={{ isUnlocked, hasPinSet, loading, setPin, unlockWithPin, unlockWithBiometrics, lock, biometricsAvailable }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
