import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, TextInput, Button, HelperText } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '@/context/AuthContext';

export default function LockScreen() {
  const { hasPinSet, setPin, unlockWithPin, unlockWithBiometrics, biometricsAvailable } = useAuth();
  const [pin, setPinInput] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState('');

  const handleSetup = async () => {
    if (pin.length < 4) {
      setError('PIN must be at least 4 digits.');
      return;
    }
    if (pin !== confirmPin) {
      setError('PINs do not match.');
      return;
    }
    await setPin(pin);
  };

  const handleUnlock = async () => {
    const ok = await unlockWithPin(pin);
    if (!ok) setError('Incorrect PIN. Try again.');
  };

  return (
    <View style={styles.container}>
      <Ionicons name="medkit" size={56} color="#0D5BBD" />
      <Text variant="headlineSmall" style={styles.title}>
        Pharma Order Book
      </Text>

      {!hasPinSet ? (
        <>
          <Text variant="bodyMedium" style={styles.subtitle}>
            Set a PIN to protect your customer and order data.
          </Text>
          <TextInput
            label="New PIN"
            value={pin}
            onChangeText={setPinInput}
            secureTextEntry
            keyboardType="number-pad"
            mode="outlined"
            style={styles.input}
          />
          <TextInput
            label="Confirm PIN"
            value={confirmPin}
            onChangeText={setConfirmPin}
            secureTextEntry
            keyboardType="number-pad"
            mode="outlined"
            style={styles.input}
          />
          {error ? <HelperText type="error">{error}</HelperText> : null}
          <Button mode="contained" onPress={handleSetup} style={styles.button}>
            Set PIN
          </Button>
        </>
      ) : (
        <>
          <Text variant="bodyMedium" style={styles.subtitle}>
            Enter your PIN to unlock
          </Text>
          <TextInput
            label="PIN"
            value={pin}
            onChangeText={setPinInput}
            secureTextEntry
            keyboardType="number-pad"
            mode="outlined"
            style={styles.input}
          />
          {error ? <HelperText type="error">{error}</HelperText> : null}
          <Button mode="contained" onPress={handleUnlock} style={styles.button}>
            Unlock
          </Button>
          {biometricsAvailable ? (
            <Button mode="text" icon="fingerprint" onPress={unlockWithBiometrics} style={styles.button}>
              Use Biometrics
            </Button>
          ) : null}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
  title: { marginTop: 12, fontWeight: '700' },
  subtitle: { marginTop: 8, marginBottom: 20, opacity: 0.7, textAlign: 'center' },
  input: { width: '100%', marginBottom: 8 },
  button: { width: '100%', marginTop: 8 },
});
