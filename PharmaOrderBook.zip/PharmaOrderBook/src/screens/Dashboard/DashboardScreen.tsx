import React, { useCallback, useState } from 'react';
import { View, ScrollView, StyleSheet, RefreshControl } from 'react-native';
import { Text, Card, Surface } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { format } from 'date-fns';
import { countOrdersToday, getRecentOrders } from '@/database/orderRepo';
import { countProducts } from '@/database/productRepo';
import { countCustomers } from '@/database/customerRepo';
import { Order } from '@/types';
import EmptyState from '@/components/EmptyState';

function StatTile({ icon, label, value, color }: { icon: any; label: string; value: number; color: string }) {
  return (
    <Surface style={styles.tile} elevation={1}>
      <View style={[styles.tileIcon, { backgroundColor: color + '1A' }]}>
        <Ionicons name={icon} size={20} color={color} />
      </View>
      <Text variant="headlineSmall" style={styles.tileValue}>
        {value}
      </Text>
      <Text variant="bodySmall" style={styles.tileLabel}>
        {label}
      </Text>
    </Surface>
  );
}

export default function DashboardScreen({ navigation }: any) {
  const [ordersToday, setOrdersToday] = useState(0);
  const [productCount, setProductCount] = useState(0);
  const [customerCount, setCustomerCount] = useState(0);
  const [recent, setRecent] = useState<Order[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    const [ot, pc, cc, rc] = await Promise.all([
      countOrdersToday(),
      countProducts(),
      countCustomers(),
      getRecentOrders(5),
    ]);
    setOrdersToday(ot);
    setProductCount(pc);
    setCustomerCount(cc);
    setRecent(rc);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  return (
    <ScrollView
      style={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      <Text variant="headlineSmall" style={styles.greeting}>
        Good day 👋
      </Text>
      <Text variant="bodyMedium" style={styles.subGreeting}>
        Here's your business snapshot for {format(new Date(), 'dd MMM yyyy')}
      </Text>

      <View style={styles.grid}>
        <StatTile icon="receipt-outline" label="Orders Today" value={ordersToday} color="#0D5BBD" />
        <StatTile icon="people-outline" label="Customers" value={customerCount} color="#00A99D" />
        <StatTile icon="cube-outline" label="Products" value={productCount} color="#F9A825" />
      </View>

      <Text variant="titleMedium" style={styles.sectionTitle}>
        Recent Orders
      </Text>
      {recent.length === 0 ? (
        <EmptyState icon="receipt-outline" title="No orders yet" subtitle="Tap + to create your first order." />
      ) : (
        recent.map((order) => (
          <Card
            key={order.id}
            style={styles.orderCard}
            onPress={() => navigation.navigate('OrderDetail', { orderId: order.id })}
          >
            <Card.Title
              title={order.customerName}
              subtitle={`${format(order.orderDate, 'dd MMM yyyy')} • ${order.totalItems} items`}
              left={(props) => <Ionicons {...props} name="document-text-outline" size={24} color="#0D5BBD" />}
            />
          </Card>
        ))
      )}
      <View style={{ height: 90 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 16, paddingTop: 12 },
  greeting: { fontWeight: '700' },
  subGreeting: { opacity: 0.6, marginBottom: 16 },
  grid: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  tile: { flex: 1, borderRadius: 16, padding: 14 },
  tileIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  tileValue: { fontWeight: '700' },
  tileLabel: { opacity: 0.6, marginTop: 2 },
  sectionTitle: { marginBottom: 8, fontWeight: '600' },
  orderCard: { marginBottom: 8, borderRadius: 14 },
});
