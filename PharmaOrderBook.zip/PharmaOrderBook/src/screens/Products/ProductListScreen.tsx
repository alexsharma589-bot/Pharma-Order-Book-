import React, { useCallback, useState } from 'react';
import { View, FlatList, StyleSheet, Pressable } from 'react-native';
import { Text, FAB, Chip, IconButton, Menu, Divider } from 'react-native-paper';
import { useFocusEffect } from '@react-navigation/native';
import SearchInput from '@/components/SearchInput';
import EmptyState from '@/components/EmptyState';
import { listProducts, deleteProduct } from '@/database/productRepo';
import { Product, ProductCategory, PRODUCT_CATEGORIES } from '@/types';
import { categoryColor } from '@/theme/theme';

export default function ProductListScreen({ navigation }: any) {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<ProductCategory | undefined>(undefined);
  const [products, setProducts] = useState<Product[]>([]);
  const [menuFor, setMenuFor] = useState<string | null>(null);

  const load = useCallback(async () => {
    const rows = await listProducts(query, category);
    setProducts(rows);
  }, [query, category]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleDelete = async (id: string) => {
    await deleteProduct(id);
    setMenuFor(null);
    load();
  };

  return (
    <View style={styles.container}>
      <SearchInput value={query} onChangeText={setQuery} placeholder="Search products, company, strength" />
      <FlatList
        data={['All', ...PRODUCT_CATEGORIES]}
        horizontal
        keyExtractor={(item) => item}
        showsHorizontalScrollIndicator={false}
        style={styles.chipRow}
        renderItem={({ item }) => (
          <Chip
            selected={(item === 'All' && !category) || category === item}
            onPress={() => setCategory(item === 'All' ? undefined : (item as ProductCategory))}
            style={styles.chip}
            compact
          >
            {item}
          </Chip>
        )}
      />
      <FlatList
        data={products}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: 100 }}
        ItemSeparatorComponent={() => <Divider />}
        ListEmptyComponent={
          <EmptyState
            icon="cube-outline"
            title="No products yet"
            subtitle="Add your first product to start building orders faster."
          />
        }
        renderItem={({ item }) => (
          <Pressable
            style={styles.row}
            onPress={() => navigation.navigate('ProductForm', { productId: item.id })}
          >
            <View style={{ flex: 1 }}>
              <Text variant="bodyLarge">
                {item.name}
                {item.strength ? ` (${item.strength})` : ''}
              </Text>
              <Text variant="bodySmall" style={styles.muted}>
                {[item.companyName, item.packing, item.mrp ? `MRP ₹${item.mrp}` : null]
                  .filter(Boolean)
                  .join(' • ')}
              </Text>
              <Chip compact style={[styles.catChip, { backgroundColor: categoryColor(item.category) + '22' }]}>
                {item.category}
              </Chip>
            </View>
            <Menu
              visible={menuFor === item.id}
              onDismiss={() => setMenuFor(null)}
              anchor={<IconButton icon="dots-vertical" onPress={() => setMenuFor(item.id)} />}
            >
              <Menu.Item
                leadingIcon="pencil"
                title="Edit"
                onPress={() => {
                  setMenuFor(null);
                  navigation.navigate('ProductForm', { productId: item.id });
                }}
              />
              <Menu.Item leadingIcon="delete" title="Delete" onPress={() => handleDelete(item.id)} />
            </Menu>
          </Pressable>
        )}
      />
      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => navigation.navigate('ProductForm', {})}
        label="Add Product"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  chipRow: { paddingHorizontal: 12, marginBottom: 4 },
  chip: { marginRight: 6 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 16 },
  muted: { opacity: 0.6, marginTop: 2 },
  catChip: { alignSelf: 'flex-start', marginTop: 6 },
  fab: { position: 'absolute', right: 16, bottom: 16 },
});
