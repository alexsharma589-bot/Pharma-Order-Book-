import React, { useEffect, useState } from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { TextInput, Button, Text, Chip, HelperText } from 'react-native-paper';
import { getProduct, upsertProduct } from '@/database/productRepo';
import { ProductCategory, PRODUCT_CATEGORIES } from '@/types';

export default function ProductFormScreen({ route, navigation }: any) {
  const productId: string | undefined = route.params?.productId;
  const [name, setName] = useState('');
  const [strength, setStrength] = useState('');
  const [packing, setPacking] = useState('');
  const [category, setCategory] = useState<ProductCategory>('Tablets');
  const [companyName, setCompanyName] = useState('');
  const [mrp, setMrp] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    navigation.setOptions({ title: productId ? 'Edit Product' : 'Add Product' });
    if (productId) {
      getProduct(productId).then((p) => {
        if (!p) return;
        setName(p.name);
        setStrength(p.strength ?? '');
        setPacking(p.packing ?? '');
        setCategory(p.category);
        setCompanyName(p.companyName ?? '');
        setMrp(p.mrp != null ? String(p.mrp) : '');
      });
    }
  }, [productId, navigation]);

  const handleSave = async () => {
    if (!name.trim()) {
      setError('Product name is required.');
      return;
    }
    setSaving(true);
    try {
      await upsertProduct({
        id: productId,
        name: name.trim(),
        strength: strength.trim() || undefined,
        packing: packing.trim() || undefined,
        category,
        companyName: companyName.trim() || undefined,
        mrp: mrp.trim() ? Number(mrp) : null,
      });
      navigation.goBack();
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      <TextInput
        label="Product Name *"
        value={name}
        onChangeText={(t) => {
          setName(t);
          setError('');
        }}
        mode="outlined"
        style={styles.input}
      />
      {error ? <HelperText type="error">{error}</HelperText> : null}

      <View style={styles.rowInputs}>
        <TextInput
          label="Strength"
          value={strength}
          onChangeText={setStrength}
          mode="outlined"
          style={[styles.input, { flex: 1, marginRight: 8 }]}
          placeholder="e.g. 500mg"
        />
        <TextInput
          label="Packing"
          value={packing}
          onChangeText={setPacking}
          mode="outlined"
          style={[styles.input, { flex: 1 }]}
          placeholder="e.g. 10x10"
        />
      </View>

      <TextInput
        label="Company Name"
        value={companyName}
        onChangeText={setCompanyName}
        mode="outlined"
        style={styles.input}
      />

      <TextInput
        label="MRP (optional)"
        value={mrp}
        onChangeText={setMrp}
        mode="outlined"
        keyboardType="decimal-pad"
        style={styles.input}
      />

      <Text variant="labelLarge" style={styles.label}>
        Category
      </Text>
      <View style={styles.chipWrap}>
        {PRODUCT_CATEGORIES.map((c) => (
          <Chip key={c} selected={category === c} onPress={() => setCategory(c)} style={styles.chip}>
            {c}
          </Chip>
        ))}
      </View>

      <Button mode="contained" onPress={handleSave} loading={saving} style={styles.saveBtn}>
        {productId ? 'Save Changes' : 'Add Product'}
      </Button>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  input: { marginBottom: 12 },
  rowInputs: { flexDirection: 'row' },
  label: { marginBottom: 8, marginTop: 4 },
  chipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 24 },
  chip: { marginBottom: 4 },
  saveBtn: { marginTop: 8, paddingVertical: 4 },
});
