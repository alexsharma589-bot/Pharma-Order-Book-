import React, { useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { List, Switch, Divider, Text, Button, Snackbar } from 'react-native-paper';
import { useAppTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';
import { createBackup, pickAndRestoreBackup } from '@/services/backupService';
import { shareFile } from '@/services/shareService';
import { syncNow, isFirebaseConfigured } from '@/services/firebaseSync';

export default function SettingsScreen() {
  const { isDark, setMode } = useAppTheme();
  const { lock } = useAuth();
  const [busy, setBusy] = useState<string | null>(null);
  const [snackbar, setSnackbar] = useState('');

  const handleBackup = async () => {
    setBusy('backup');
    try {
      const uri = await createBackup();
      await shareFile(uri, 'application/json');
    } catch (e: any) {
      setSnackbar(e.message ?? 'Backup failed.');
    } finally {
      setBusy(null);
    }
  };

  const handleRestore = async () => {
    setBusy('restore');
    try {
      const { restored } = await pickAndRestoreBackup();
      setSnackbar(restored ? `Restored ${restored} records.` : 'No file selected.');
    } catch (e: any) {
      setSnackbar(e.message ?? 'Restore failed.');
    } finally {
      setBusy(null);
    }
  };

  const handleSync = async () => {
    setBusy('sync');
    try {
      if (!isFirebaseConfigured) {
        setSnackbar('Cloud sync is not configured yet. Add Firebase config to enable it.');
        return;
      }
      const result = await syncNow('local-user'); // replace with real Firebase Auth uid once signed in
      setSnackbar(`Synced. Pushed ${result.pushed}, pulled ${result.pulled}.`);
    } catch (e: any) {
      setSnackbar(e.message ?? 'Sync failed.');
    } finally {
      setBusy(null);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <List.Section>
        <List.Subheader>Appearance</List.Subheader>
        <List.Item
          title="Dark Mode"
          left={(props) => <List.Icon {...props} icon="weather-night" />}
          right={() => <Switch value={isDark} onValueChange={(v) => setMode(v ? 'dark' : 'light')} />}
        />
      </List.Section>
      <Divider />

      <List.Section>
        <List.Subheader>Security</List.Subheader>
        <List.Item
          title="Lock App Now"
          description="Require PIN / biometric on next open"
          left={(props) => <List.Icon {...props} icon="lock" />}
          onPress={lock}
        />
      </List.Section>
      <Divider />

      <List.Section>
        <List.Subheader>Data</List.Subheader>
        <List.Item
          title="Backup Data"
          description="Export all products, customers and orders to a file"
          left={(props) => <List.Icon {...props} icon="cloud-upload-outline" />}
          onPress={handleBackup}
        />
        <List.Item
          title="Restore Data"
          description="Import from a previously saved backup file"
          left={(props) => <List.Icon {...props} icon="cloud-download-outline" />}
          onPress={handleRestore}
        />
        <List.Item
          title="Sync Now"
          description={isFirebaseConfigured ? 'Push/pull changes with the cloud' : 'Not configured — see README'}
          left={(props) => <List.Icon {...props} icon="sync" />}
          onPress={handleSync}
        />
      </List.Section>
      <Divider />

      <List.Section>
        <List.Subheader>About</List.Subheader>
        <View style={styles.about}>
          <Text variant="bodyMedium">Pharma Order Book v1.0.0</Text>
          <Text variant="bodySmall" style={styles.muted}>
            Built for pharmaceutical distributors and medical representatives to create orders in under a minute.
          </Text>
        </View>
      </List.Section>

      <Snackbar visible={!!snackbar} onDismiss={() => setSnackbar('')} duration={3000}>
        {snackbar}
      </Snackbar>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  about: { paddingHorizontal: 16, paddingVertical: 8 },
  muted: { opacity: 0.6, marginTop: 4 },
});
