import React, { useCallback, useState } from 'react';
import { View, FlatList, StyleSheet, Pressable, Linking } from 'react-native';
import { Text, FAB, IconButton, Menu, Divider } from 'react-native-paper';
import { useFocusEffect } from '@react-navigation/native';
import SearchInput from '@/components/SearchInput';
import EmptyState from '@/components/EmptyState';
import { listCustomers, deleteCustomer } from '@/database/customerRepo';
import { Customer } from '@/types';

export default function CustomerListScreen({ navigation }: any) {
  const [query, setQuery] = useState('');
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [menuFor, setMenuFor] = useState<string | null>(null);

  const load = useCallback(async () => {
    setCustomers(await listCustomers(query));
  }, [query]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleDelete = async (id: string) => {
    await deleteCustomer(id);
    setMenuFor(null);
    load();
  };

  return (
    <View style={styles.container}>
      <SearchInput value={query} onChangeText={setQuery} placeholder="Search by name, shop, mobile, area" />
      <FlatList
        data={customers}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: 100 }}
        ItemSeparatorComponent={() => <Divider />}
        ListEmptyComponent={
          <EmptyState icon="people-outline" title="No customers yet" subtitle="Add a customer to start placing orders." />
        }
        renderItem={({ item }) => (
          <Pressable style={styles.row} onPress={() => navigation.navigate('CustomerForm', { customerId: item.id })}>
            <View style={{ flex: 1 }}>
              <Text variant="bodyLarge">{item.name}</Text>
              <Text variant="bodySmall" style={styles.muted}>
                {[item.shopName, item.area].filter(Boolean).join(' • ')}
              </Text>
              {item.mobile ? (
                <Pressable onPress={() => Linking.openURL(`tel:${item.mobile}`)}>
                  <Text variant="bodySmall" style={styles.phone}>
                    📞 {item.mobile}
                  </Text>
                </Pressable>
              ) : null}
            </View>
            <Menu
              visible={menuFor === item.id}
              onDismiss={() => setMenuFor(null)}
              anchor={<IconButton icon="dots-vertical" onPress={() => setMenuFor(item.id)} />}
            >
              <Menu.Item
                leadingIcon="pencil"
                title="Edit"
                onPress={() => {
                  setMenuFor(null);
                  navigation.navigate('CustomerForm', { customerId: item.id });
                }}
              />
              <Menu.Item leadingIcon="delete" title="Delete" onPress={() => handleDelete(item.id)} />
            </Menu>
          </Pressable>
        )}
      />
      <FAB icon="plus" style={styles.fab} onPress={() => navigation.navigate('CustomerForm', {})} label="Add Customer" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 16 },
  muted: { opacity: 0.6, marginTop: 2 },
  phone: { color: '#0D5BBD', marginTop: 4 },
  fab: { position: 'absolute', right: 16, bottom: 16 },
});
