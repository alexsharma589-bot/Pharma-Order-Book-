import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import { TextInput, Button, HelperText } from 'react-native-paper';
import { getCustomer, upsertCustomer } from '@/database/customerRepo';

export default function CustomerFormScreen({ route, navigation }: any) {
  const customerId: string | undefined = route.params?.customerId;
  const [name, setName] = useState('');
  const [shopName, setShopName] = useState('');
  const [mobile, setMobile] = useState('');
  const [area, setArea] = useState('');
  const [gstNumber, setGstNumber] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    navigation.setOptions({ title: customerId ? 'Edit Customer' : 'Add Customer' });
    if (customerId) {
      getCustomer(customerId).then((c) => {
        if (!c) return;
        setName(c.name);
        setShopName(c.shopName ?? '');
        setMobile(c.mobile ?? '');
        setArea(c.area ?? '');
        setGstNumber(c.gstNumber ?? '');
      });
    }
  }, [customerId, navigation]);

  const handleSave = async () => {
    if (!name.trim()) {
      setError('Customer name is required.');
      return;
    }
    setSaving(true);
    try {
      await upsertCustomer({
        id: customerId,
        name: name.trim(),
        shopName: shopName.trim() || undefined,
        mobile: mobile.trim() || undefined,
        area: area.trim() || undefined,
        gstNumber: gstNumber.trim() || undefined,
      });
      navigation.goBack();
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      <TextInput
        label="Customer Name *"
        value={name}
        onChangeText={(t) => {
          setName(t);
          setError('');
        }}
        mode="outlined"
        style={styles.input}
      />
      {error ? <HelperText type="error">{error}</HelperText> : null}

      <TextInput label="Shop Name" value={shopName} onChangeText={setShopName} mode="outlined" style={styles.input} />
      <TextInput
        label="Mobile Number"
        value={mobile}
        onChangeText={setMobile}
        mode="outlined"
        keyboardType="phone-pad"
        style={styles.input}
      />
      <TextInput label="Area / City" value={area} onChangeText={setArea} mode="outlined" style={styles.input} />
      <TextInput
        label="GST Number (optional)"
        value={gstNumber}
        onChangeText={setGstNumber}
        mode="outlined"
        autoCapitalize="characters"
        style={styles.input}
      />

      <Button mode="contained" onPress={handleSave} loading={saving} style={styles.saveBtn}>
        {customerId ? 'Save Changes' : 'Add Customer'}
      </Button>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  input: { marginBottom: 12 },
  saveBtn: { marginTop: 8, paddingVertical: 4 },
});
