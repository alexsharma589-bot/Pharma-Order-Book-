import React, { useCallback, useState } from 'react';
import { View, FlatList, StyleSheet, Pressable } from 'react-native';
import { Text, FAB, IconButton, Menu, Divider, Chip } from 'react-native-paper';
import { useFocusEffect } from '@react-navigation/native';
import { format } from 'date-fns';
import DateTimePicker from '@react-native-community/datetimepicker';
import SearchInput from '@/components/SearchInput';
import EmptyState from '@/components/EmptyState';
import { listOrders, deleteOrder, duplicateOrder } from '@/database/orderRepo';
import { Order } from '@/types';

export default function OrderListScreen({ navigation }: any) {
  const [query, setQuery] = useState('');
  const [dateFilter, setDateFilter] = useState<Date | null>(null);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [menuFor, setMenuFor] = useState<string | null>(null);

  const load = useCallback(async () => {
    const rows = await listOrders({
      searchQuery: query,
      dateFrom: dateFilter?.getTime(),
      dateTo: dateFilter?.getTime(),
    });
    setOrders(rows);
  }, [query, dateFilter]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleDelete = async (id: string) => {
    await deleteOrder(id);
    setMenuFor(null);
    load();
  };

  const handleDuplicate = async (id: string) => {
    const newOrder = await duplicateOrder(id);
    setMenuFor(null);
    navigation.navigate('CreateOrder', { orderId: newOrder.id });
  };

  return (
    <View style={styles.container}>
      <SearchInput value={query} onChangeText={setQuery} placeholder="Search by customer or shop" />
      <View style={styles.filterRow}>
        <Chip icon="calendar" onPress={() => setShowDatePicker(true)} style={styles.chip}>
          {dateFilter ? format(dateFilter, 'dd MMM yyyy') : 'Filter by date'}
        </Chip>
        {dateFilter ? (
          <Chip icon="close" onPress={() => setDateFilter(null)} style={styles.chip}>
            Clear
          </Chip>
        ) : null}
      </View>
      {showDatePicker && (
        <DateTimePicker
          value={dateFilter ?? new Date()}
          mode="date"
          onChange={(_, selected) => {
            setShowDatePicker(false);
            if (selected) setDateFilter(selected);
          }}
        />
      )}

      <FlatList
        data={orders}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: 100 }}
        ItemSeparatorComponent={() => <Divider />}
        ListEmptyComponent={
          <EmptyState icon="receipt-outline" title="No orders found" subtitle="Tap + to create a new order." />
        }
        renderItem={({ item }) => (
          <Pressable style={styles.row} onPress={() => navigation.navigate('OrderDetail', { orderId: item.id })}>
            <View style={{ flex: 1 }}>
              <Text variant="bodyLarge">{item.customerName}</Text>
              <Text variant="bodySmall" style={styles.muted}>
                {format(item.orderDate, 'dd MMM yyyy')} • {item.totalItems} items
                {item.shopName ? ` • ${item.shopName}` : ''}
              </Text>
            </View>
            <Menu
              visible={menuFor === item.id}
              onDismiss={() => setMenuFor(null)}
              anchor={<IconButton icon="dots-vertical" onPress={() => setMenuFor(item.id)} />}
            >
              <Menu.Item
                leadingIcon="pencil"
                title="Edit"
                onPress={() => {
                  setMenuFor(null);
                  navigation.navigate('CreateOrder', { orderId: item.id });
                }}
              />
              <Menu.Item leadingIcon="content-copy" title="Duplicate" onPress={() => handleDuplicate(item.id)} />
              <Menu.Item leadingIcon="delete" title="Delete" onPress={() => handleDelete(item.id)} />
            </Menu>
          </Pressable>
        )}
      />
      <FAB icon="plus" style={styles.fab} onPress={() => navigation.navigate('CreateOrder', {})} label="New Order" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  filterRow: { flexDirection: 'row', paddingHorizontal: 12, marginBottom: 4, gap: 8 },
  chip: { marginRight: 6 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 16 },
  muted: { opacity: 0.6, marginTop: 2 },
  fab: { position: 'absolute', right: 16, bottom: 16 },
});
