import React, { useEffect, useState } from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { Text, Card, Button, Divider, ActivityIndicator, Snackbar } from 'react-native-paper';
import { format } from 'date-fns';
import { getOrderWithItems } from '@/database/orderRepo';
import { Order } from '@/types';
import { generateOrderPdf, printOrder } from '@/services/pdfService';
import { exportOrderToExcel } from '@/services/excelService';
import { shareFile, shareOrderTextToWhatsApp } from '@/services/shareService';

export default function OrderDetailScreen({ route, navigation }: any) {
  const orderId: string = route.params.orderId;
  const [order, setOrder] = useState<Order | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [snackbar, setSnackbar] = useState('');

  useEffect(() => {
    getOrderWithItems(orderId).then(setOrder);
  }, [orderId]);

  if (!order) {
    return (
      <View style={styles.center}>
        <ActivityIndicator />
      </View>
    );
  }

  const handlePdfShare = async () => {
    setBusy('pdf');
    try {
      const uri = await generateOrderPdf(order);
      await shareFile(uri, 'application/pdf');
    } catch (e: any) {
      setSnackbar(e.message ?? 'Failed to export PDF.');
    } finally {
      setBusy(null);
    }
  };

  const handleExcelShare = async () => {
    setBusy('excel');
    try {
      const uri = await exportOrderToExcel(order);
      await shareFile(uri, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    } catch (e: any) {
      setSnackbar(e.message ?? 'Failed to export Excel.');
    } finally {
      setBusy(null);
    }
  };

  const handleWhatsApp = async () => {
    setBusy('whatsapp');
    try {
      await shareOrderTextToWhatsApp(order);
    } catch (e: any) {
      setSnackbar(e.message ?? 'WhatsApp not available.');
    } finally {
      setBusy(null);
    }
  };

  const handlePrint = async () => {
    setBusy('print');
    try {
      await printOrder(order);
    } catch (e: any) {
      setSnackbar(e.message ?? 'Failed to print.');
    } finally {
      setBusy(null);
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView style={{ flex: 1 }}>
        <Card style={styles.headerCard}>
          <Card.Content>
            <Text variant="titleLarge">{order.customerName}</Text>
            {order.shopName ? <Text variant="bodyMedium" style={styles.muted}>{order.shopName}</Text> : null}
            <Text variant="bodySmall" style={styles.muted}>
              {format(order.orderDate, 'dd MMM yyyy')} • {order.totalItems} items
            </Text>
          </Card.Content>
        </Card>

        <Card style={styles.itemsCard}>
          <Card.Content>
            {(order.items ?? []).map((item, idx) => (
              <View key={item.id}>
                <View style={styles.itemRow}>
                  <Text variant="bodyMedium" style={{ flex: 1 }}>
                    {idx + 1}. {item.productName}
                    {item.strength ? ` (${item.strength})` : ''}
                  </Text>
                  <Text variant="bodyMedium">
                    {item.quantity}
                    {item.freeQuantity ? ` +${item.freeQuantity}F` : ''}
                  </Text>
                </View>
                {idx < (order.items?.length ?? 0) - 1 ? <Divider style={{ marginVertical: 6 }} /> : null}
              </View>
            ))}
          </Card.Content>
        </Card>

        {order.remarks ? (
          <Card style={styles.itemsCard}>
            <Card.Content>
              <Text variant="labelLarge">Remarks</Text>
              <Text variant="bodyMedium" style={styles.muted}>
                {order.remarks}
              </Text>
            </Card.Content>
          </Card>
        ) : null}

        <View style={{ height: 16 }} />
      </ScrollView>

      <View style={styles.actionGrid}>
        <Button mode="contained-tonal" icon="file-pdf-box" loading={busy === 'pdf'} onPress={handlePdfShare} style={styles.actionBtn}>
          PDF
        </Button>
        <Button mode="contained-tonal" icon="file-excel" loading={busy === 'excel'} onPress={handleExcelShare} style={styles.actionBtn}>
          Excel
        </Button>
        <Button mode="contained-tonal" icon="whatsapp" loading={busy === 'whatsapp'} onPress={handleWhatsApp} style={styles.actionBtn}>
          WhatsApp
        </Button>
        <Button mode="contained-tonal" icon="printer" loading={busy === 'print'} onPress={handlePrint} style={styles.actionBtn}>
          Print
        </Button>
      </View>
      <Button mode="contained" style={styles.editBtn} onPress={() => navigation.navigate('CreateOrder', { orderId })}>
        Edit Order
      </Button>

      <Snackbar visible={!!snackbar} onDismiss={() => setSnackbar('')} duration={2500}>
        {snackbar}
      </Snackbar>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  headerCard: { marginBottom: 10, borderRadius: 14 },
  itemsCard: { marginBottom: 10, borderRadius: 14 },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between' },
  muted: { opacity: 0.6, marginTop: 2 },
  actionGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 8 },
  actionBtn: { flexGrow: 1, minWidth: '45%' },
  editBtn: { paddingVertical: 4 },
});
