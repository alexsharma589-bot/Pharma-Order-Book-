import React, { useEffect, useMemo, useState } from 'react';
import { View, FlatList, StyleSheet, Pressable } from 'react-native';
import { Text, TextInput, Button, IconButton, Divider, Surface, Snackbar } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';
import DateTimePicker from '@react-native-community/datetimepicker';
import ProductPickerModal from '@/components/ProductPickerModal';
import CustomerPickerModal from '@/components/CustomerPickerModal';
import { getOrderWithItems, saveOrder } from '@/database/orderRepo';
import { Customer, OrderItem, Product } from '@/types';

type DraftItem = Omit<OrderItem, 'id' | 'orderId'> & { localId: string };

export default function CreateOrderScreen({ route, navigation }: any) {
  const orderId: string | undefined = route.params?.orderId;

  const [customer, setCustomer] = useState<Customer | null>(null);
  const [orderDate, setOrderDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [remarks, setRemarks] = useState('');
  const [items, setItems] = useState<DraftItem[]>([]);
  const [productPickerVisible, setProductPickerVisible] = useState(false);
  const [customerPickerVisible, setCustomerPickerVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [snackbar, setSnackbar] = useState('');

  useEffect(() => {
    navigation.setOptions({ title: orderId ? 'Edit Order' : 'New Order' });
    if (orderId) {
      getOrderWithItems(orderId).then((order) => {
        if (!order) return;
        setCustomer({
          id: order.customerId,
          name: order.customerName,
          shopName: order.shopName,
          createdAt: 0,
          updatedAt: 0,
          deleted: 0,
          dirty: 0,
        });
        setOrderDate(new Date(order.orderDate));
        setRemarks(order.remarks ?? '');
        setItems(
          (order.items ?? []).map((it) => ({
            localId: it.id,
            productId: it.productId,
            productName: it.productName,
            strength: it.strength,
            packing: it.packing,
            quantity: it.quantity,
            freeQuantity: it.freeQuantity,
          }))
        );
      });
    }
  }, [orderId, navigation]);

  const totalItems = useMemo(
    () => items.reduce((sum, it) => sum + (it.quantity || 0) + (it.freeQuantity || 0), 0),
    [items]
  );

  const addProduct = (product: Product) => {
    if (items.some((it) => it.productId === product.id)) {
      setSnackbar(`${product.name} is already in this order.`);
      return;
    }
    setItems((prev) => [
      ...prev,
      {
        localId: `${product.id}-${Date.now()}`,
        productId: product.id,
        productName: product.name,
        strength: product.strength,
        packing: product.packing,
        quantity: 1,
        freeQuantity: 0,
      },
    ]);
  };

  const updateItem = (localId: string, patch: Partial<DraftItem>) => {
    setItems((prev) => prev.map((it) => (it.localId === localId ? { ...it, ...patch } : it)));
  };

  const removeItem = (localId: string) => {
    setItems((prev) => prev.filter((it) => it.localId !== localId));
  };

  const handleSave = async () => {
    if (!customer) {
      setSnackbar('Please select a customer.');
      return;
    }
    if (items.length === 0) {
      setSnackbar('Add at least one product.');
      return;
    }
    setSaving(true);
    try {
      await saveOrder({
        id: orderId,
        customerId: customer.id,
        customerName: customer.name,
        shopName: customer.shopName,
        orderDate: orderDate.getTime(),
        remarks: remarks.trim() || undefined,
        items: items.map((it) => ({
          productId: it.productId,
          productName: it.productName,
          strength: it.strength,
          packing: it.packing,
          quantity: Number(it.quantity) || 0,
          freeQuantity: Number(it.freeQuantity) || 0,
        })),
      });
      navigation.goBack();
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.container}>
      <Pressable style={styles.customerCard} onPress={() => setCustomerPickerVisible(true)}>
        <Ionicons name="person-circle-outline" size={28} color="#0D5BBD" />
        <View style={{ flex: 1, marginLeft: 10 }}>
          {customer ? (
            <>
              <Text variant="bodyLarge">{customer.name}</Text>
              <Text variant="bodySmall" style={styles.muted}>
                {customer.shopName || 'Tap to change customer'}
              </Text>
            </>
          ) : (
            <Text variant="bodyLarge" style={styles.placeholderText}>
              Select Customer *
            </Text>
          )}
        </View>
        <Ionicons name="chevron-forward" size={20} color="#9AA7BD" />
      </Pressable>

      <Pressable style={styles.dateRow} onPress={() => setShowDatePicker(true)}>
        <Ionicons name="calendar-outline" size={18} color="#0D5BBD" />
        <Text variant="bodyMedium" style={{ marginLeft: 8 }}>
          {format(orderDate, 'dd MMM yyyy')}
        </Text>
      </Pressable>
      {showDatePicker && (
        <DateTimePicker
          value={orderDate}
          mode="date"
          onChange={(_, selected) => {
            setShowDatePicker(false);
            if (selected) setOrderDate(selected);
          }}
        />
      )}

      <FlatList
        data={items}
        keyExtractor={(it) => it.localId}
        style={styles.list}
        ItemSeparatorComponent={() => <Divider />}
        ListHeaderComponent={
          <Pressable style={styles.addProductBtn} onPress={() => setProductPickerVisible(true)}>
            <Ionicons name="add-circle" size={20} color="#0D5BBD" />
            <Text style={styles.addProductText}>Add Product</Text>
          </Pressable>
        }
        ListEmptyComponent={
          <Text style={styles.emptyHint}>No products added yet. Tap "Add Product" to search and pick one.</Text>
        }
        renderItem={({ item }) => (
          <Surface style={styles.itemRow} elevation={0}>
            <View style={{ flex: 1 }}>
              <Text variant="bodyMedium" numberOfLines={2}>
                {item.productName}
                {item.strength ? ` (${item.strength})` : ''}
              </Text>
              {item.packing ? (
                <Text variant="bodySmall" style={styles.muted}>
                  {item.packing}
                </Text>
              ) : null}
              <View style={styles.qtyRow}>
                <TextInput
                  label="Qty"
                  value={String(item.quantity)}
                  onChangeText={(t) => updateItem(item.localId, { quantity: Number(t.replace(/[^0-9]/g, '')) || 0 })}
                  keyboardType="number-pad"
                  mode="outlined"
                  dense
                  style={styles.qtyInput}
                />
                <TextInput
                  label="Free"
                  value={String(item.freeQuantity)}
                  onChangeText={(t) =>
                    updateItem(item.localId, { freeQuantity: Number(t.replace(/[^0-9]/g, '')) || 0 })
                  }
                  keyboardType="number-pad"
                  mode="outlined"
                  dense
                  style={styles.qtyInput}
                />
              </View>
            </View>
            <IconButton icon="close" size={18} onPress={() => removeItem(item.localId)} />
          </Surface>
        )}
      />

      <TextInput
        label="Remarks (optional)"
        value={remarks}
        onChangeText={setRemarks}
        mode="outlined"
        style={styles.remarks}
        multiline
      />

      <Surface style={styles.footer} elevation={3}>
        <Text variant="titleMedium">Total Items: {totalItems}</Text>
        <Button mode="contained" onPress={handleSave} loading={saving} style={styles.saveBtn}>
          {orderId ? 'Update Order' : 'Save Order'}
        </Button>
      </Surface>

      <ProductPickerModal
        visible={productPickerVisible}
        onDismiss={() => setProductPickerVisible(false)}
        onSelect={addProduct}
      />
      <CustomerPickerModal
        visible={customerPickerVisible}
        onDismiss={() => setCustomerPickerVisible(false)}
        onSelect={setCustomer}
      />
      <Snackbar visible={!!snackbar} onDismiss={() => setSnackbar('')} duration={2500}>
        {snackbar}
      </Snackbar>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  customerCard: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 12,
    padding: 14,
    borderRadius: 14,
    backgroundColor: '#EEF3FB',
  },
  placeholderText: { color: '#0D5BBD' },
  muted: { opacity: 0.6 },
  dateRow: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 16, marginBottom: 4 },
  list: { flex: 1, paddingHorizontal: 12 },
  addProductBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    marginBottom: 4,
  },
  addProductText: { color: '#0D5BBD', marginLeft: 6, fontWeight: '600' },
  emptyHint: { opacity: 0.6, textAlign: 'center', marginTop: 24, paddingHorizontal: 24 },
  itemRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  qtyRow: { flexDirection: 'row', marginTop: 6, gap: 8 },
  qtyInput: { width: 90 },
  remarks: { marginHorizontal: 12, marginBottom: 8 },
  footer: { padding: 14, borderTopLeftRadius: 16, borderTopRightRadius: 16 },
  saveBtn: { marginTop: 10, paddingVertical: 4 },
});
