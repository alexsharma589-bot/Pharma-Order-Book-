import React, { useEffect, useState, useCallback } from 'react';
import { View, FlatList, StyleSheet, Pressable } from 'react-native';
import { Modal, Portal, Text, Chip, Divider } from 'react-native-paper';
import SearchInput from './SearchInput';
import EmptyState from './EmptyState';
import { listProducts } from '@/database/productRepo';
import { Product } from '@/types';
import { categoryColor } from '@/theme/theme';

interface Props {
  visible: boolean;
  onDismiss: () => void;
  onSelect: (product: Product) => void;
}

export default function ProductPickerModal({ visible, onDismiss, onSelect }: Props) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Product[]>([]);

  const search = useCallback(async (q: string) => {
    const rows = await listProducts(q);
    setResults(rows);
  }, []);

  useEffect(() => {
    if (visible) search(query);
  }, [visible, query, search]);

  useEffect(() => {
    if (!visible) setQuery('');
  }, [visible]);

  return (
    <Portal>
      <Modal visible={visible} onDismiss={onDismiss} contentContainerStyle={styles.modal}>
        <Text variant="titleMedium" style={styles.heading}>
          Select Product
        </Text>
        <SearchInput value={query} onChangeText={setQuery} placeholder="Search by name, company, strength" />
        <FlatList
          data={results}
          keyExtractor={(item) => item.id}
          style={{ maxHeight: 420 }}
          ItemSeparatorComponent={() => <Divider />}
          ListEmptyComponent={
            <EmptyState
              icon="cube-outline"
              title="No products found"
              subtitle="Try a different search, or add this product in Product Master first."
            />
          }
          renderItem={({ item }) => (
            <Pressable
              style={styles.row}
              onPress={() => {
                onSelect(item);
                onDismiss();
              }}
            >
              <View style={{ flex: 1 }}>
                <Text variant="bodyLarge">
                  {item.name}
                  {item.strength ? ` (${item.strength})` : ''}
                </Text>
                <Text variant="bodySmall" style={styles.muted}>
                  {[item.companyName, item.packing].filter(Boolean).join(' • ')}
                </Text>
              </View>
              <Chip compact style={{ backgroundColor: categoryColor(item.category) + '22' }}>
                {item.category}
              </Chip>
            </Pressable>
          )}
        />
      </Modal>
    </Portal>
  );
}

const styles = StyleSheet.create({
  modal: { backgroundColor: 'white', margin: 16, borderRadius: 16, padding: 12, maxHeight: '85%' },
  heading: { paddingHorizontal: 8, paddingTop: 4 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 8 },
  muted: { opacity: 0.6, marginTop: 2 },
});
