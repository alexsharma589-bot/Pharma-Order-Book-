import React from 'react';
import { Searchbar } from 'react-native-paper';
import { StyleSheet } from 'react-native';

interface Props {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
}

export default function SearchInput({ value, onChangeText, placeholder = 'Search' }: Props) {
  return (
    <Searchbar
      placeholder={placeholder}
      value={value}
      onChangeText={onChangeText}
      style={styles.bar}
      elevation={0}
    />
  );
}

const styles = StyleSheet.create({
  bar: {
    marginHorizontal: 12,
    marginTop: 8,
    marginBottom: 4,
  },
});
