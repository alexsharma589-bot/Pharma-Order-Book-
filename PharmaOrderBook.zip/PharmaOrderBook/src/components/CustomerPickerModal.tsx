import React, { useEffect, useState, useCallback } from 'react';
import { View, FlatList, StyleSheet, Pressable } from 'react-native';
import { Modal, Portal, Text, Divider } from 'react-native-paper';
import SearchInput from './SearchInput';
import EmptyState from './EmptyState';
import { listCustomers } from '@/database/customerRepo';
import { Customer } from '@/types';

interface Props {
  visible: boolean;
  onDismiss: () => void;
  onSelect: (customer: Customer) => void;
}

export default function CustomerPickerModal({ visible, onDismiss, onSelect }: Props) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Customer[]>([]);

  const search = useCallback(async (q: string) => {
    const rows = await listCustomers(q);
    setResults(rows);
  }, []);

  useEffect(() => {
    if (visible) search(query);
  }, [visible, query, search]);

  useEffect(() => {
    if (!visible) setQuery('');
  }, [visible]);

  return (
    <Portal>
      <Modal visible={visible} onDismiss={onDismiss} contentContainerStyle={styles.modal}>
        <Text variant="titleMedium" style={styles.heading}>
          Select Customer
        </Text>
        <SearchInput value={query} onChangeText={setQuery} placeholder="Search by name, shop, mobile, area" />
        <FlatList
          data={results}
          keyExtractor={(item) => item.id}
          style={{ maxHeight: 420 }}
          ItemSeparatorComponent={() => <Divider />}
          ListEmptyComponent={
            <EmptyState
              icon="person-outline"
              title="No customers found"
              subtitle="Add this customer in Customer Master first."
            />
          }
          renderItem={({ item }) => (
            <Pressable
              style={styles.row}
              onPress={() => {
                onSelect(item);
                onDismiss();
              }}
            >
              <Text variant="bodyLarge">{item.name}</Text>
              <Text variant="bodySmall" style={styles.muted}>
                {[item.shopName, item.area, item.mobile].filter(Boolean).join(' • ')}
              </Text>
            </Pressable>
          )}
        />
      </Modal>
    </Portal>
  );
}

const styles = StyleSheet.create({
  modal: { backgroundColor: 'white', margin: 16, borderRadius: 16, padding: 12, maxHeight: '85%' },
  heading: { paddingHorizontal: 8, paddingTop: 4 },
  row: { paddingVertical: 12, paddingHorizontal: 8 },
  muted: { opacity: 0.6, marginTop: 2 },
});
