import 'react-native-gesture-handler';
import React from 'react';
import { NavigationContainer, DefaultTheme as NavLightTheme, DarkTheme as NavDarkTheme } from '@react-navigation/native';
import { PaperProvider } from 'react-native-paper';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { ThemeProvider, useAppTheme } from '@/context/ThemeContext';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import RootNavigator from '@/navigation/RootNavigator';
import LockScreen from '@/screens/Auth/LockScreen';

function Gate() {
  const { isUnlocked, loading } = useAuth();
  const { theme, isDark } = useAppTheme();

  if (loading) return null;

  const navTheme = isDark ? NavDarkTheme : NavLightTheme;

  return (
    <PaperProvider theme={theme}>
      <NavigationContainer theme={navTheme}>
        <StatusBar style={isDark ? 'light' : 'dark'} />
        {isUnlocked ? <RootNavigator /> : <LockScreen />}
      </NavigationContainer>
    </PaperProvider>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <AuthProvider>
          <Gate />
        </AuthProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
